# JIMMY RUN — Complete Game Spec (for Grok Build)

**What this is:** the full design + content spec of JIMMY RUN, the JnJ Arcade
pseudo-3D corridor runner, live at https://jnjarcade.win/games/jimmy-run.
Everything a rebuild needs: mechanics, tuning constants, all 191 voice lines,
the voice-dispatch rules, the character-swap system, obstacle progression, and
the integration contracts the JnJ Arcade site requires.

**Included in this zip:**
- `JIMMY-RUN-SPEC.md` — this file
- `jimmy-run.html` — the complete current game (single self-contained file, canvas 2D)
- `jimmy-run-pack.json` — all 191 voice clips (base64 mp3, keyed by djb2 hash, format below)
- `jimmy-run-art/` — the Jimmy Dash sprite/texture assets currently in use
  (robot frames, coins, beam, barrier, banner, menu-bg — plus carpet/stone/water
  textures that are vendored but currently UNUSED after a corridor-texture
  experiment was reverted)

---

## 1. IDENTITY

- Title: **JIMMY RUN** · slug `jimmy-run` · accent/ink `#ff6b35`
- Genre label: TEMPLE RUN × MINION RUSH
- Premise: Jimmy (white/gold toy robot, seen from BEHIND, running away from
  camera) sprints the show's studio corridors while THE DEAD AIR — a wall of
  static — chases from behind. Clean running pulls away from it; mistakes let
  it close in. Joe (bronze/rust robot) can be tagged in to take over the run.
- Camera: pseudo-3D corridor, 3 lanes, vanishing point ~1/3 from top.
- Canvas: 400×700 world units, scaled to fit viewport (mobile-first, portrait).

## 2. CONTROLS

- Swipe LEFT/RIGHT: change lane (3 lanes: -1, 0, +1). Deadzone 17px.
- Swipe UP: jump (40-tick airtime, parabolic, apex 78 world px).
- Swipe DOWN: slide (34 ticks).
- Desktop: arrow keys. NO other keyboard requirement.
- Tap on speaker icon (top-right): cycles sound mode 🔊 tones → 🎙️ voice → 🔇 mute.
  Double-tap while in 🎙️ mode: toggles ONLY Joe's flap/step barks off (jump+slide
  commentary), everything else keeps speaking. Persisted in localStorage.
- NO confirm()/alert()/prompt() anywhere (silently dead on phones).

## 3. CORE TUNING (current live values)

```js
const SPEED0     = 0.052;    // z-units per tick at start
const SPEED_MAX  = 0.115;
const SPEED_RAMP = 0.0000045;// per metre
const LANE_LERP  = 0.24;
const JUMP_TICKS = 40;       // total airtime
const JUMP_H     = 78;       // apex elevation (world px at player scale)
const SLIDE_TICKS= 34;
const HIT_Z      = 0.55;     // obstacle z at which collision resolves
const HIT_WINDOW = 0.34;     // z tolerance
const STATIC_DECAY = 0.0011; // dead-air proximity decay per tick while clean
const STATIC_STUMBLE = 0.34; // proximity added on stumble
const STATIC_CREEP = 0.00016;// passive creep per tick (never fully safe)
const HYPE_NEED  = 8;
const HYPE_MS    = 5200;
const ROCKET_MS  = 2600;
const MAGNET_MS  = 6500;
const COFFEE_MS  = 8000;    // ×2 all score
const GOLD_MS    = 8000;    // lollipops worth 100
const SLOWMO_MS  = 5000;    // world at 55% speed — breathing room
const MEGA_MS    = 4000;    // giant, invincible, auto-mows everything
const METRES_PER_Z = 3;
```

- dt is normalized to 60fps ticks: `dt = (now - last) / (1000/60)`, clamped 0.1–3.
- Speed ramps with distance; rocket ×1.55, hype ×1.25, slow-mo ×0.55.
- Score: +1 per metre (via addScore), lollipop/coin pickup +25 (+50 in hype,
  +100 with gold perk), troll mow 50×combo, MEGA smashing any obstacle +30.
- ☕ coffee perk doubles EVERYTHING through one addScore() choke point.

## 4. THE DEAD AIR (lose condition)

- `deadAir` 0..1: static wall proximity. Passive creep +0.00016/tick,
  decay −0.0011/tick while clean, stumble +0.34. At 1.0 → death.
- Rendered as TV static creeping in from screen edges, red flash above 0.55.
- Death → ArcadeScores overlay (options object!) → restart loop.

## 5. OBSTACLES + FLOOR-GATED INTRICACY

Kinds: `sofa` (jump over — spiked beam art), `mic` (LOW ON AIR SIGN RIG —
slide under; glowing red sign, truss posts, hazard stripes, text must be fully
readable), `rack` (lane blocker — stone block art), `chair` (rolls across
lanes), `troll` (lane blocker, mowable with rocket/hype/MEGA).

Fairness by construction (hard rules, all verified):
- rack walls ALWAYS leave ≥1 open lane
- nothing kills that appeared <0.5s ago; spawn spacing never below reaction distance
- randomness dresses, never decides winnability

Escalation by floor (floorIdx): Merch Room+ (≥2): jump-then-slide combos
(sofa then mic, same lane, 0.85z apart). Server Room+ (≥4): drifting-gap racks
(the open lane slides sideways as it approaches), two-lane troll pairs (third
always clear). The Roof+ (≥6): THE GAUNTLET — rack telegraphs the open lane,
all-lane rig (slide safe anywhere), sofa waiting in that same open lane.
Difficulty divisor `dist/6800` so it climbs across all 8 floors.

## 6. FLOORS (8, distance-gated, palette + announcement each)

```js
const FLOORS = [
  { at: 0,    name: 'Basement Archive', wall: '#7a4a34', floor: '#4a382c', glow: '#e8a13c' },
  { at: 500,  name: 'Tape Library',     wall: '#6a4a44', floor: '#463830', glow: '#e8b95c' },
  { at: 1200, name: 'Merch Room',       wall: '#7a4454', floor: '#4a3438', glow: '#f088a0' },
  { at: 2100, name: 'Writers Room',     wall: '#7a5a34', floor: '#4c3e28', glow: '#f0c860' },
  { at: 3200, name: 'Server Room',      wall: '#4a5a44', floor: '#384432', glow: '#80d0a0' },
  { at: 4500, name: 'Studio Floor',     wall: '#8a4444', floor: '#503232', glow: '#ff8080' },
  { at: 6000, name: 'The Roof',         wall: '#54506a', floor: '#3c3a4c', glow: '#a0a0e0' },
  { at: 7800, name: 'Above the Show',   wall: '#4a4a62', floor: '#363646', glow: '#9090d0' },
];
```

On floor change: sfx + floor announcement VO (active runner speaks THEIR line),
confetti, floating 🏢 banner.

## 7. PERKS (7, spawn pool weighted, ~0.085/wave)

- 🚀 rocket (2.6s): speed ×1.55, mows trolls, holds the static back
- 🛡 shield: absorbs one hit ("SAVED!" + save VO)
- 🧲 magnet (6.5s): pulls pickups toward player lane
- ☕ coffee (8s): ×2 ALL score
- 🌟 gold (8s): pickups worth 100
- ⏱ slow-mo (5s): world ×0.55 + blue tint
- 💪 MEGA (4s): 2× giant, invincible, smashes sofa/mic/rack/chair/troll +30 each
Plus 🔥 HYPE meter: 8 pickups fills it → 5.2s hype (speed ×1.25, pickups 50,
mows trolls, rainbow aura).
HUD: active-perk chips (26×26) with draining time bars.

## 8. JOE TAG-IN (playable character swap)

- After Merch Room (floorIdx ≥ 2), a tag pickup spawns (🎧 when Jimmy runs,
  🎤 when Joe runs), cooldown ~900–1400m, never two on screen.
- Collecting it swaps `activeRunner` jimmy↔joe: confetti, "🎧 JOE TAKES OVER" /
  "🎤 JIMMY TAKES OVER" banner, and a spoken two-line handoff (departing
  character first, then incoming — both at full gain, fires in BOTH tones and
  voice modes, like floor announcements).
- Joe's sprite = same 14 frames tinted bronze (sepia+hue-rotate offscreen pass).
- HUD shows 🎤 JIMMY / 🎧 JOE next to the score.
- VOICE ROLE SWAP is the key design: whoever is NOT running becomes the
  commentator. Jimmy runs → Joe deadpans (JOE_BARKS). Joe runs → Jimmy hypes
  (JIMMY_BARKS). The ACTIVE runner voices his own first-person milestones
  (floor entries, shield saves, personal best, top score).

## 9. SOUND SYSTEM (3-way, house pattern)

- Modes: 🔊 tones (WebAudio synth per event + spoken floor/death/PB moments) ·
  🎙️ voice (everything spoken) · 🔇 mute. localStorage `sfxMode_jimmy-run`.
- Lazy AudioContext, resumed on first gesture (iOS). Silent during attract.
- Gains: JIMMY_GAIN 1.15, JOE_GAIN 0.4 (commentary), jump/slide barks ×0.85.
  Death/floor/PB/top/tag lines always at JIMMY_GAIN (1.15) whoever speaks.
- Joe bark rotation: per-event rotating index (VO.rot), 140ms min spacing.
- Death monologue: alternates JIMMY/JOE per death (localStorage), tiered by
  score (see DEATH_TIERS below), spoken in BOTH tones + voice modes.
- Idle chatter: every 22–42s in voice mode.

## 10. VOICE PACK FORMAT

- `jimmy-run-pack.json`: `{"voice": {"<djb2hex>": "<base64 mp3>"}}` — 191 clips.
- Key = djb2 of `WHO|exact line text`:
  ```js
  function djb2(s) { let h = 5381; for (let i = 0; i < s.length; i++)
    h = ((h * 33) ^ s.charCodeAt(i)) >>> 0; return h.toString(16); }
  // key = djb2('JIMMY' + '|' + 'Personal best!')
  ```
- Clips: Chatterbox TTS (canonical jimmy2/joe2 voices), silence-trimmed,
  loudnorm −16 LUFS, 24kHz mono mp3 40k. IMPORTANT: identical (who, text)
  pairs share keys across ALL JnJ games — clips are reused between games'
  packs for free. If lines are kept verbatim, existing clips keep working.
- Lazy-fetched on load (skipped in mute), decoded once, cached.

## 11. ALL VOICE CONTENT (verbatim — 191 distinct lines)

### Master line table (who|text pairs, exactly as keyed in the pack)
```js
const VO_LINES = [
  // ── reused (identical keys → clips shared from flap-fight / dead-air-dash packs) ──
  ["JIMMY", "Personal best!"], ["JIMMY", "New personal best!"], ["JIMMY", "That's a record!"],
  ["JIMMY", "Best flight of your life!"], ["JIMMY", "Past your best. Keep going!"],
  ["JIMMY", "New record. That just happened!"],
  ["JIMMY", "Top scorer!"], ["JIMMY", "Number one!"], ["JIMMY", "Top of the board!"],
  ["JIMMY", "You're number one!"], ["JIMMY", "Highest score in the whole arcade!"],
  ["JIMMY", "The record is yours!"],
  ["JIMMY", "That was brief!"], ["JIMMY", "The warm-up run. Classic!"],
  ["JIMMY", "We never speak of this one!"], ["JIMMY", "Even the pipes feel bad!"],
  ["JIMMY", "A speedrun of losing!"], ["JIMMY", "The bird barely woke up!"],
  ["JIMMY", "Straight down. Committed, though!"],
  ["JIMMY", "What a run!"], ["JIMMY", "Down in a blaze of glory!"], ["JIMMY", "The bird will fly again!"],
  ["JIMMY", "Respectable! The pipes disagree, but respectable!"],
  ["JIMMY", "Solid flying. Questionable landing!"], ["JIMMY", "That was a proper flight!"],
  ["JIMMY", "Now THAT was flying!"], ["JIMMY", "The bird is a professional!"],
  ["JIMMY", "Someone's been practising!"], ["JIMMY", "That run had chapters!"],
  ["JIMMY", "Big score. Bigger heart!"],
  ["JIMMY", "Legendary flight! Frame it!"], ["JIMMY", "The pipes will tell stories about you!"],
  ["JIMMY", "That wasn't a run, that was a career!"], ["JIMMY", "I ran out of things to count!"],
  ["JIMMY", "Historic! Genuinely historic!"],
  ["JOE", "that was quick."], ["JOE", "a bold strategy."], ["JOE", "we don't talk about this one."],
  ["JOE", "the pipes send their thanks."], ["JOE", "blink and you missed it. I blinked."],
  ["JOE", "gravity one, bird nil."], ["JOE", "practice. presumably."],
  ["JOE", "big boom."], ["JOE", "oh no."], ["JOE", "bye bye."], ["JOE", "that's that."],
  ["JOE", "a reasonable effort. then a wall."], ["JOE", "decent. the ending needs work."],
  ["JOE", "the middle part was good."],
  ["JOE", "genuinely decent."], ["JOE", "I watched most of that. worth it."],
  ["JOE", "the pipes needed a break anyway."], ["JOE", "quality flapping. noted in the ledger."],
  ["JOE", "that was fine. very fine."],
  ["JOE", "I stood up. briefly."], ["JOE", "that deserves a slow nod. here it is."],
  ["JOE", "the leaderboard felt that."], ["JOE", "remarkable. I don't say that."],
  ["JOE", "I'll be quoting this run."],
  ["JOE", "ten in a row. I'm mildly moved."],
  ["JOE", "fifteen straight. this is getting silly."],
  ["JOE", "twenty. I'm framing this one."],
  ["JIMMY", "Basement Archive! It smells like history!"],
  ["JIMMY", "Tape Library! Every episode ever!"],
  ["JIMMY", "Merch Room! Buy or ByeBye lives here!"],
  ["JIMMY", "Writers Room! Where the jokes are born!"],
  ["JIMMY", "Server Room! Keep it cool, keep climbing!"],
  ["JIMMY", "Studio Floor! We're basically on air!"],
  ["JIMMY", "The Roof! Nothing above us but sky!"],
  ["JIMMY", "Above the show! Uncharted territory!"],
  ["JIMMY", "That was close! Too close!"], ["JIMMY", "Still alive! Somehow!"],
  ["JIMMY", "The shield! I love the shield!"], ["JIMMY", "Heart rate: unprofessional!"],
  ["JOE", "close one."], ["JOE", "mind the gap."], ["JOE", "not ideal."],
  ["JOE", "rocket. naturally."], ["JOE", "up we go. rapidly."], ["JOE", "that's just showing off."],
  ["JOE", "the ceiling is no longer a choice."],
  ["JOE", "shield acquired."], ["JOE", "one free mistake."], ["JOE", "insurance."],
  ["JOE", "magnet on."], ["JOE", "the lollipops come to you now."], ["JOE", "lazy. effective."],
  ["JOE", "we are attracting objects now."],
  ["JOE", "hype mode. apparently."], ["JOE", "he's glowing. that's new."], ["JOE", "sustain it. or don't."],
  ["JOE", "troll deleted."], ["JOE", "blocked and reported."], ["JOE", "the comment section thins."],
  ["JOE", "off he goes."], ["JOE", "climbing. again."], ["JOE", "the static is patient."],
  ["JOE", "I'll be here."], ["JOE", "the game begins. try not to fall."], ["JOE", "begin. I will observe."],
  ["JOE", "still watching."], ["JOE", "I had a sofa like that."], ["JOE", "the archive misses him."],
  ["JOE", "this floor is my favourite."], ["JOE", "he can't hear me. probably for the best."],
  ["JOE", "somewhere, a kettle boils."], ["JOE", "gravity's having an off day."],
  ["JOE", "the podcast studio has terrible building codes."],
  ["JOE", "how many floors does this building actually have."],
  ["JOE", "ooh."], ["JOE", "shiny."], ["JOE", "nice."],
  // ── new for JIMMY RUN ──
  ["JOE", "hup."], ["JOE", "airborne."], ["JOE", "technically flying."],
  ["JOE", "limbo."], ["JOE", "under it."], ["JOE", "low bridge."],
  ["JOE", "that was furniture."], ["JOE", "he met a sofa."], ["JOE", "the corridor won that one."],
  ["JOE", "chair. incoming."],
  ["JOE", "espresso. of course."], ["JOE", "caffeinated. dangerous."],
  ["JOE", "everything's gold now."], ["JOE", "premium lollipops."],
  ["JOE", "time. slower. somehow."], ["JOE", "bullet time. allegedly."],
  ["JOE", "he's enormous."], ["JOE", "big Jimmy. very big."],
  // ── TAG-IN: Joe becomes playable (Osimo 2026-08-18) ──
  ["JIMMY", "Up and over!"], ["JIMMY", "Big hop, Joe!"],
  ["JIMMY", "Slide it, Joe!"], ["JIMMY", "Under the wire!"],
  ["JIMMY", "Oof, furniture!"], ["JIMMY", "Shake it off, Joe!"],
  ["JIMMY", "So close!"], ["JIMMY", "Inches to spare!"],
  ["JIMMY", "Rocket power, let's go!"], ["JIMMY", "Nothing's stopping him now!"],
  ["JIMMY", "Shield's up!"], ["JIMMY", "One free hit!"],
  ["JIMMY", "Magnet mode!"], ["JIMMY", "Pulling 'em all in!"],
  ["JIMMY", "Hype mode, Joe!"], ["JIMMY", "He's glowing, literally!"],
  ["JIMMY", "Double points, let's go!"], ["JIMMY", "Caffeine kicks in!"],
  ["JIMMY", "Golden lollipops!"], ["JIMMY", "Everything's worth double!"],
  ["JIMMY", "Time's crawling, use it, Joe!"], ["JIMMY", "Slow-mo, baby!"],
  ["JIMMY", "He's huge, Joe!"], ["JIMMY", "Unstoppable Joe!"],
  ["JIMMY", "Troll down!"], ["JIMMY", "Cleared the comments!"],
  ["JIMMY", "Go get 'em, Joe!"], ["JIMMY", "Show 'em how it's done!"],
  ["JIMMY", "Still got this, Joe!"], ["JIMMY", "One floor at a time!"],
  ["JIMMY", "The studio's rooting for you!"],
  ["JIMMY", "Nice grab!"], ["JIMMY", "Love it!"],
  ["JIMMY", "Tag — you're up!"], ["JIMMY", "All yours, don't trip!"],
  ["JIMMY", "I'm back in it!"], ["JIMMY", "Let's gooo!"], ["JIMMY", "Jimmy's taking it home!"],
  ["JOE", "structurally concerning."],
  ["JOE", "every episode. still not backed up properly."],
  ["JOE", "buy or don't. your call."], ["JOE", "the jokes are worse in person."],
  ["JOE", "don't touch anything blinking."], ["JOE", "technically live. try not to swear."],
  ["JOE", "nobody approved this floor."], ["JOE", "this shouldn't exist."],
  ["JOE", "still standing."], ["JOE", "the shield earns its keep."], ["JOE", "closer than I'd like."],
  ["JOE", "personal best. noted."], ["JOE", "new record. don't get used to it."],
  ["JOE", "past my best. moving on."],
  ["JOE", "top of the board. as expected."], ["JOE", "number one. someone had to be."],
  ["JOE", "the record's mine now."],
  ["JOE", "fine. I'll show him how it's done."], ["JOE", "taking over. try to keep up."],
  ["JOE", "someone has to do this properly."],
  ["JOE", "your turn. don't embarrass us."], ["JOE", "back to you."], ["JOE", "I've done my bit."],
];
```

### Joe's commentary banks (when JIMMY runs)
```js
const JOE_BARKS = {
  jump:    ["hup.", "airborne.", "technically flying."],
  slide:   ["limbo.", "under it.", "low bridge."],
  stumble: ["that was furniture.", "he met a sofa.", "the corridor won that one.", "not ideal."],
  nearMiss:["close one.", "mind the gap."],
  rocket:  ["rocket. naturally.", "up we go. rapidly.", "that's just showing off.",
            "the ceiling is no longer a choice."],
  shield:  ["shield acquired.", "one free mistake.", "insurance."],
  magnet:  ["magnet on.", "the lollipops come to you now.", "lazy. effective.",
            "we are attracting objects now."],
  hype:    ["hype mode. apparently.", "he's glowing. that's new.", "sustain it. or don't."],
  coffee:  ["espresso. of course.", "caffeinated. dangerous."],
  gold:    ["everything's gold now.", "premium lollipops."],
  slowmo:  ["time. slower. somehow.", "bullet time. allegedly."],
  mega:    ["he's enormous.", "big Jimmy. very big."],
  mow:     ["troll deleted.", "blocked and reported.", "the comment section thins.", "big boom."],
  start:   ["off he goes.", "the static is patient.", "I'll be here.",
            "the game begins. try not to fall.", "begin. I will observe."],
  idle:    ["still watching.", "I had a sofa like that.", "the archive misses him.",
            "this floor is my favourite.", "he can't hear me. probably for the best.",
            "somewhere, a kettle boils.", "gravity's having an off day.",
            "the podcast studio has terrible building codes.",
            "how many floors does this building actually have."],
  pickup:  ["ooh.", "shiny.", "nice."],
};
```

### Jimmy's commentary banks (when JOE runs)
```js
const JIMMY_BARKS = {
  jump:    ["Up and over!", "Big hop, Joe!"],
  slide:   ["Slide it, Joe!", "Under the wire!"],
  stumble: ["Oof, furniture!", "Shake it off, Joe!"],
  nearMiss:["So close!", "Inches to spare!"],
  rocket:  ["Rocket power, let's go!", "Nothing's stopping him now!"],
  shield:  ["Shield's up!", "One free hit!"],
  magnet:  ["Magnet mode!", "Pulling 'em all in!"],
  hype:    ["Hype mode, Joe!", "He's glowing, literally!"],
  coffee:  ["Double points, let's go!", "Caffeine kicks in!"],
  gold:    ["Golden lollipops!", "Everything's worth double!"],
  slowmo:  ["Time's crawling, use it, Joe!", "Slow-mo, baby!"],
  mega:    ["He's huge, Joe!", "Unstoppable Joe!"],
  mow:     ["Troll down!", "Cleared the comments!"],
  start:   ["Go get 'em, Joe!", "Show 'em how it's done!"],
  idle:    ["Still got this, Joe!", "One floor at a time!", "The studio's rooting for you!"],
  pickup:  ["Nice grab!", "Love it!"],
};
```

### Floor announcements (active runner speaks his own)
```js
const JIMMY_FLOOR_VO = [
  "Basement Archive! It smells like history!",
  "Tape Library! Every episode ever!",
  "Merch Room! Buy or ByeBye lives here!",
  "Writers Room! Where the jokes are born!",
  "Server Room! Keep it cool, keep climbing!",
  "Studio Floor! We're basically on air!",
  "The Roof! Nothing above us but sky!",
  "Above the show! Uncharted territory!",
];
const JOE_FLOOR_VO = [
  "structurally concerning.",
  "every episode. still not backed up properly.",
  "buy or don't. your call.",
  "the jokes are worse in person.",
  "don't touch anything blinking.",
  "technically live. try not to swear.",
  "nobody approved this floor.",
  "this shouldn't exist.",
];
```

### Shield-save lines (active runner)
```js
const JIMMY_SAVE_VO = ["That was close! Too close!", "Still alive! Somehow!",
                       "The shield! I love the shield!", "Heart rate: unprofessional!"];
const JOE_SAVE_VO = ["still standing.", "the shield earns its keep.", "closer than I'd like."];
```

### Death monologues (score-tiered, alternating host)
```js
const DEATH_TIERS = [
  { min: 15000,
    JIMMY: ["Legendary flight! Frame it!", "The pipes will tell stories about you!",
            "That wasn't a run, that was a career!", "I ran out of things to count!",
            "Historic! Genuinely historic!"],
    JOE:   ["I stood up. briefly.", "that deserves a slow nod. here it is.",
            "the leaderboard felt that.", "remarkable. I don't say that.", "I'll be quoting this run."] },
  { min: 5000,
    JIMMY: ["Now THAT was flying!", "The bird is a professional!", "Someone's been practising!",
            "That run had chapters!", "Big score. Bigger heart!"],
    JOE:   ["genuinely decent.", "I watched most of that. worth it.", "the pipes needed a break anyway.",
            "quality flapping. noted in the ledger.", "that was fine. very fine."] },
  { min: 500,
    JIMMY: ["What a run!", "Down in a blaze of glory!", "The bird will fly again!",
            "Respectable! The pipes disagree, but respectable!", "Solid flying. Questionable landing!",
            "That was a proper flight!"],
    JOE:   ["big boom.", "oh no.", "bye bye.", "that's that.", "a reasonable effort. then a wall.",
            "decent. the ending needs work.", "the middle part was good."] },
  { min: 0,
    JIMMY: ["That was brief!", "The warm-up run. Classic!", "We never speak of this one!",
            "Even the pipes feel bad!", "A speedrun of losing!", "The bird barely woke up!",
            "Straight down. Committed, though!"],
    JOE:   ["that was quick.", "a bold strategy.", "we don't talk about this one.",
            "the pipes send their thanks.", "blink and you missed it. I blinked.",
            "gravity one, bird nil.", "practice. presumably."] },
];
```

### Troll-mow combo acknowledgements (Joe, at ×10/×15/×20)
```js
const COMBO_VO = {
  10: "ten in a row. I'm mildly moved.",
  15: "fifteen straight. this is getting silly.",
  20: "twenty. I'm framing this one.",
};
```

### Personal-best + top-score callouts (active runner, with confetti + banner)
```js
const JIMMY_PB_VO  = ["Personal best!", "New personal best!", "That's a record!",
                      "Best flight of your life!", "Past your best. Keep going!",
                      "New record. That just happened!"];
const JIMMY_TOP_VO = ["Top scorer!", "Number one!", "Top of the board!",
                      "You're number one!", "Highest score in the whole arcade!",
                      "The record is yours!"];
const JOE_PB_VO  = ["personal best. noted.", "new record. don't get used to it.", "past my best. moving on."];
const JOE_TOP_VO = ["top of the board. as expected.", "number one. someone had to be.", "the record's mine now."];
```

### Tag-in handoff lines (departing speaks, then incoming)
```js
const TAG_JIMMY_OUT = ["Tag — you're up!", "All yours, don't trip!", "Go get 'em, Joe!"];
const TAG_JIMMY_IN  = ["I'm back in it!", "Let's gooo!", "Jimmy's taking it home!"];
const TAG_JOE_IN    = ["fine. I'll show him how it's done.", "taking over. try to keep up.",
                        "someone has to do this properly."];
const TAG_JOE_OUT   = ["your turn. don't embarrass us.", "back to you.", "I've done my bit."];
```

## 12. CHARACTER VOICE RULES (personality guard — NON-NEGOTIABLE)

- JIMMY: high energy, hype, self-aware comedy. NEVER Gen Z slang ("no cap",
  "fr", "vibe" etc). NEVER spells words letter-by-letter. No hedging.
- JOE: flat, dry, surgical understatement. Skepticism targets JIMMY, not facts.
  Late-landing jokes. Lowercase delivery style in his lines is intentional.
- Any new lines must be written in these voices or they will be rejected.

## 13. SCORE / LEADERBOARD INTEGRATION (site contract)

- Game-over: `ArcadeScores.show({ game: 'jimmy-run', title: 'JIMMY RUN',
  score, accent: '#ff6b35', onClose: restart })` — OPTIONS OBJECT, never
  positional args. Script: `../arcade-scores.js`.
- Top score fetched from `/api/scores?game=jimmy-run` for the "top scorer"
  callout logic (pb from localStorage `hs_jimmy-run`).
- PB/top each announce ONCE per run; crossing both at once fires only top.

## 14. ATTRACT MODE (cassette requirement)

- `?attract=1` (and cassette embedding) must run a competent self-playing demo:
  AI reads nearest threat, jumps sofas, slides rigs, lane-dodges racks.
  SILENT (no sfx/VO), never dies (stumble/death early-return in attract),
  never shows game-over UI.

## 15. HOUSE RULES (JnJ Arcade platform, hard requirements)

- Single self-contained HTML file + same-origin assets. NO CDNs whatsoever.
- Mobile-first: swipe-only play, touch-action none, passive:false, fullscreen
  attempt on start, works at 390×844.
- No browser dialogs. No keyboard requirement.
- Level 1 must be clearable by a first-time phone player.
- `?play=1` skips the start overlay (cassette pass-through).
- Cache: any changed asset needs a bumped `?v=N` query.

## 16. CURRENT ART ASSETS (in jimmy-run-art/)

- Robot frames (256px, white/gold, back view): run-1..6, jump-1..4, slide-1..4.
  Frame selection: run = bobPh cycle; jump = 4 frames across the arc;
  slide = 4 frames across the slide. Joe = same frames, bronze-tinted at load.
- coin-1..4: spinning gold temple coin (pickup art, 130ms/frame).
- beam.png: spiked wooden beam (the jump-over obstacle art).
- barrier.png: gold-trimmed stone block (the lane-blocker art).
- banner.png: red/gold hanging banner (wall decor).
- menu-bg.jpg: torch-lit temple corridor (INSERT COIN overlay backdrop).
- carpet.jpg / stone.jpg / water.jpg: UNUSED texture experiments (a per-strip
  textured corridor was tried and reverted — the drawn studio corridor stayed).

## 17. THE CORRIDOR (current, drawn — kept after texture experiment failed)

Pseudo-3D segment projection (OutRun pattern): exponential z-spacing
`zAt = n => 0.30 * Math.pow(1.095, n)`, 46 strips/frame, HORIZON 232,
camera depth 1.2, shared `corridorShift(z)` curve for corridor AND entities.
Studio dressing per segment cadence: brass sconces w/ glow halos (%4),
gold-bevel Jimmy/Joe portrait busts (%7), glowing red ON AIR wall signs (%11),
wall clocks (%8+3), JIM & JOE screens (%13), bookshelves (%10+5), hanging
banners (%6+2), sagging cables (%2), brass dado rail, wood-beam ceiling,
stage-light cones (%9). Floor: wood strips + red rug runner + brass lane dashes.
8-floor palette tinting via FLOORS table lerp.

## 18. WHAT OSIMO LIKED / DISLIKED (design history — do not regress these)

- LIKED: the low ON AIR sign rigs you slide under (keep them); the studio
  corridor look; real pre-rendered robot sprites; wide readable sign text.
- DISLIKED/REVERTED: live WebGL/Three.js character (broke on his phone);
  per-strip textured temple corridor ("didn't work"); tiny abstract-shape
  characters ("moving squares"); intro/title frames inside cassette previews.
- The game must NEVER lag on phones. 60fps is the bar.
